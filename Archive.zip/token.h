#include <iostream>
#include <ctype.h>//Funções de caracteres
#include <string>

using namespace std;

/*
1. letter → [a-zA-Z]
2. digit → [0-9]
3. ID → letter (letter | digit | _ )∗
4. integerconstant → digit+
5. charconstant → ‘ch’ | ‘\n’ | ‘\0’, onde ch é qualquer caractere ASCII imprimível (como
especificado pela função isprint(), exceto \ e aspas simples.
6. stringconstant → “(ch)*”, onde ch é qualquer caractere ASCII imprimível (como es-
pecificado pela função isprint(), exceto aspas duplas e \n .
7. Operadores → + | - | * | / | = | == | != | <= | < | >= | > | && | || | !
8. Separadores → ( | ) | { | } | [ | ] | , | ;
9. Comentários devem ser ignorados. Seguem o formato de C e podem ser em linha ou
em bloco. O comentário em linha é iniciado pelos caracteres // e encerrado por nova
linha e o comentário em bloco é delimitado por /* e * /.
10. Espaços em branco devem ser ignorados.
11. Palavras reservadas: void, char, int, if, else, while, for, return
12. O final do arquivo é representado por EOF.
*/

enum Names 
{
    UNDEF = 0,
    //Nomes e atributos dos tokens da linguagem
    LETTER = 1,
    DIGIT = 2,
    ID = 3,
    INTEGER_CONSTANT = 4,
    CHAR_CONSTANT = 5,
    STRING_CONSTANT = 6,
    OPERATOR = 7,
    SEPARATORS   = 8,
    COMMENT = 9,
    SPACE = 10,
    RESERVADED = 11,
    END_OF_FILE
};

class Token 
{
    public: 
        int name;
        int attribute;
        string lexeme;
    
        Token(int name)
        {
            this->name = name;
            attribute = UNDEF;
        }

        Token(int name, string l)
        {
            this->name = name;
            attribute = UNDEF;
            lexeme = l;
        }
        
        Token(int name, int attr)
        {
            this->name = name;
            attribute = attr;
        }
};
